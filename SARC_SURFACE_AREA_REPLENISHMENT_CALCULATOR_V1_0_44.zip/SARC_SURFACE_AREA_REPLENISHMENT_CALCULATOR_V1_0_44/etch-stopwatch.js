
(function(){
'use strict';
const DENSITY={Al:2.70,Fe:7.87};
const AREA=51.6128;
const LIMIT=270000;
function calculate(metal,seconds,initialText,finalText){
 const initialRaw=String(initialText??'').trim(),finalRaw=String(finalText??'').trim();
 if(!initialRaw||!finalRaw||!Number.isFinite(Number(initialRaw))||!Number.isFinite(Number(finalRaw)))return {status:'empty'};
 const first=Number(initialRaw),last=Number(finalRaw),sec=Number(seconds),density=DENSITY[metal];
 if(!(first>0)||!(last>=0)||!(sec>0)||!density)return {status:'invalid'};
 if(last>first)return {status:'increase'};
 const delta=first-last;
 const rate=delta*10000/(AREA*density*(sec/60));
 return {status:'ok',lossMg:delta*1000,umMin:rate,milsSideHr:rate*60/25.4};
}
function formatElapsed(ms){
 const tenths=Math.floor(Math.max(0,ms)/100);
 const min=Math.floor(tenths/600);
 const sec=Math.floor(tenths/10)%60;
 return String(min).padStart(2,'0')+':'+String(sec).padStart(2,'0')+'.'+(tenths%10);
}
class Stopwatch{
 constructor(o={}){
  this.now=o.now||(()=>performance.now());
  this.schedule=o.schedule||((fn)=>setInterval(fn,60));
  this.unschedule=o.unschedule||((id)=>clearInterval(id));
  this.onTick=o.onTick||(()=>{});
  this.onAlert=o.onAlert||(()=>{});
  this.elapsed=0;this.startedAt=0;this.running=false;this.alerted=false;this.timer=null;
 }
 current(){return this.elapsed+(this.running?Math.max(0,this.now()-this.startedAt):0);}
 tick(){
  const time=this.current();
  if(time>=LIMIT&&!this.alerted){this.alerted=true;try{this.onAlert()}catch{}}
  this.onTick(time,this.alerted);
  return time;
 }
 start(){
  if(this.running)return;
  this.startedAt=this.now();
  this.running=true;
  if(this.timer===null)this.timer=this.schedule(()=>this.tick());
  this.tick();
 }
 stop(){
  if(!this.running)return;
  this.elapsed=this.current();
  this.running=false;
  if(this.timer!==null){this.unschedule(this.timer);this.timer=null;}
  this.tick();
 }
 reset(){
  this.running=false;this.elapsed=0;this.startedAt=0;
  if(this.timer!==null){this.unschedule(this.timer);this.timer=null;}
  this.alerted=false;this.tick();
 }
}
const API={calculate,formatElapsed,Stopwatch};
if(typeof module!=='undefined'&&module.exports)module.exports=API;
if(typeof window==='undefined'||!window.document)return;
window.SARC_Etch=API;
document.addEventListener('DOMContentLoaded',()=>{
 const page=document.getElementById('page-etch');
 if(!page)return;
 const byId=id=>document.getElementById(id);
 const warning=byId('etchWarning');
 const draw=()=>{
  const metal=page.querySelector('input[name="etchMetal"]:checked')?.value||'Al';
  const seconds=page.querySelector('input[name="etchDuration"]:checked')?.value||'300';
  const result=calculate(metal,seconds,byId('etchInitialMass').value,byId('etchFinalMass').value);
  byId('etchLoss').textContent=result.status==='ok'?result.lossMg.toFixed(2)+' mg':'—';
  byId('etchMicrons').textContent=result.status==='ok'?result.umMin.toFixed(4):'—';
  byId('etchMils').textContent=result.status==='ok'?result.milsSideHr.toFixed(4):'—';
  const message=result.status==='increase'?'중량 증가: 에칭레이트 산출 불가':result.status==='invalid'?'초기 중량은 0 초과, 최종 중량은 0 이상이어야 합니다.':'';
  warning.textContent=message;warning.classList.toggle('hidden',!message);
 };
 page.querySelectorAll('input[name="etchMetal"],input[name="etchDuration"],#etchInitialMass,#etchFinalMass').forEach(el=>{
  el.addEventListener('input',draw);el.addEventListener('change',draw);
 });
 draw();
 const timeEl=byId('etchStopwatchTime');
 const stopwatch=new Stopwatch({
  onTick:(ms,red)=>{timeEl.textContent=formatElapsed(ms);timeEl.classList.toggle('alert',red);},
  onAlert:()=>{try{if(typeof navigator!=='undefined'&&typeof navigator.vibrate==='function')navigator.vibrate(300);}catch{}}
 });
 byId('etchStart').addEventListener('click',()=>stopwatch.start());
 byId('etchStop').addEventListener('click',()=>stopwatch.stop());
 byId('etchReset').addEventListener('click',()=>stopwatch.reset());
 document.addEventListener('visibilitychange',()=>stopwatch.tick());
 stopwatch.tick();
});
})();
